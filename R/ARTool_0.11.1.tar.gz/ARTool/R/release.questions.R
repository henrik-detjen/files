# Release questions for devtools::release()
# 
# Author: mjskay
###############################################################################


release_questions <- function() {
    c(
        "Is README.md up to date?"
    )
}