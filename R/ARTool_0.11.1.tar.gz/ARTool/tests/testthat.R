library(testthat)
library(ARTool)

test_check("ARTool")
